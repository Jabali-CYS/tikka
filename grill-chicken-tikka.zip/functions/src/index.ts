import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { onDocumentUpdated } from "firebase-functions/v2/firestore";

// Initialize Firebase Admin SDK for infinite/backend privilege
initializeApp();
const db = getFirestore();

/**
 * 1. validateAndPlaceOrder (HTTPS Callable)
 *
 * Accepts raw cart inputs, performs strict server-authoritative recalculation against
 * verified DB prices/zones/coupons, and commits the finalized order securely.
 */
export const validateAndPlaceOrder = onCall(async (request) => {
  // Authentication Guard
  if (!request.auth) {
    throw new HttpsError(
      "unauthenticated",
      "Authentication is required to place an order."
    );
  }

  const uid = request.auth.uid;
  const data = request.data || {};

  // Input Structure Validation
  const items = data.items;
  const zoneId = data.zoneId;
  const couponCode = data.couponCode ? String(data.couponCode).toUpperCase().trim() : null;
  const fulfillmentType = data.fulfillmentType || "delivery";
  const address = data.address || null;
  const paymentMethod = data.paymentMethod || "Cash on Delivery";
  const customerName = data.customerName || "Customer";
  const customerPhone = data.customerPhone || "";

  if (!Array.isArray(items) || items.length === 0) {
    throw new HttpsError(
      "invalid-argument",
      "Order must contain at least one valid menu item."
    );
  }

  if (fulfillmentType === "delivery" && (!zoneId || !address)) {
    throw new HttpsError(
      "invalid-argument",
      "Delivery zone and detailed physical address are required for shipping."
    );
  }

  try {
    return await db.runTransaction(async (transaction) => {
      let subtotal = 0.0;

      // 1. Recalculate prices directly from the authoritative Firestore catalog
      for (const item of items) {
        if (!item.productId || typeof item.quantity !== "number" || item.quantity <= 0) {
          throw new HttpsError(
            "invalid-argument",
            "Invalid format for standard item parameters."
          );
        }

        const productRef = db.collection("products").doc(item.productId);
        const productDoc = await transaction.get(productRef);

        if (!productDoc.exists || productDoc.data()?.isDeleted === true) {
          throw new HttpsError(
            "failed-precondition",
            `No active menu record was found for product: ${item.productId}`
          );
        }

        const prodData = productDoc.data()!;
        const basePrice = parseFloat(prodData.price || "0");
        let itemSum = basePrice;

        // Verify side option costs Authoritatively
        const sideId = item.selectedSide;
        if (sideId && typeof sideId === "string" && sideId.trim() !== "") {
          const sideOptions: any[] = prodData.sideOptions || [];
          const sideMatch = sideOptions.find((o) => o.id === sideId);
          if (sideMatch) {
            itemSum += parseFloat(sideMatch.price || "0");
          } else {
            throw new HttpsError(
              "failed-precondition",
              `Chosen side add-on '${sideId}' does not belong to product '${item.productId}'.`
            );
          }
        }

        subtotal += itemSum * item.quantity;
      }

      // 2. Authoritative Delivery Zone Fee Lookup
      let deliveryFee = 0.0;
      if (fulfillmentType === "delivery" && zoneId) {
        const zoneRef = db.collection("delivery_zones").doc(zoneId);
        const zoneDoc = await transaction.get(zoneRef);

        if (!zoneDoc.exists) {
          throw new HttpsError(
            "failed-precondition",
            "Specified delivery zone is unrecognized."
          );
        }

        const zoneData = zoneDoc.data()!;
        deliveryFee = parseFloat(zoneData.fee || "0");
        const minOrder = parseFloat(zoneData.minOrder || "0");

        if (subtotal < minOrder) {
          throw new HttpsError(
            "failed-precondition",
            `Subtotal (${subtotal} JOD) is below the minimum order floor (${minOrder} JOD) for ${zoneData.name}.`
          );
        }
      }

      // 3. Dynamic Tax Formulation (checking settings/system_settings with graceful fallback)
      const settingsRef = db.collection("settings").doc("system_settings");
      const settingsDoc = await transaction.get(settingsRef);

      let taxRate = 0.05; // Fallback default 5%
      let taxEnabled = true;

      if (settingsDoc.exists) {
        const sData = settingsDoc.data()!;
        if (sData.taxEnabled === false) {
          taxEnabled = false;
        }
        if (typeof sData.taxRate === "number") {
          taxRate = sData.taxRate / 100.0;
        }
      }

      const taxes = taxEnabled ? parseFloat((subtotal * taxRate).toFixed(3)) : 0.0;

      // 4. Coupon Verification and Discounts Calculations
      let discount = 0.0;
      let appliedCouponId: string | null = null;

      if (couponCode) {
        const couponQuery = db.collection("coupons")
          .where("code", "==", couponCode)
          .where("isDeleted", "==", false)
          .limit(1);

        const couponSnap = await transaction.get(couponQuery);

        if (couponSnap.empty) {
          throw new HttpsError("not-found", "Invalid or deleted coupon code.");
        }

        const couponDoc = couponSnap.docs[0];
        const couponData = couponDoc.data();

        // Expired Verification
        const expiry = new Date(couponData.expiryDate);
        if (expiry.getTime() < Date.now()) {
          throw new HttpsError("failed-precondition", "The entered coupon has expired.");
        }

        // Global Usage Limits Check
        const maxLimit = parseInt(couponData.usageLimit || "0");
        const currentCount = parseInt(couponData.usedCount || "0");
        if (maxLimit > 0 && currentCount >= maxLimit) {
          throw new HttpsError("failed-precondition", "Coupon campaign limit reached.");
        }

        // Per-user restriction (Preventing coupon duplication fraud)
        const usageCheck = await db.collection("coupon_redemptions")
          .where("customerUid", "==", uid)
          .where("couponCode", "==", couponCode)
          .limit(1)
          .get();

        if (!usageCheck.empty) {
          throw new HttpsError("already-exists", "You have already used this coupon.");
        }

        // Check product subtotal floor
        const minCouponOrder = parseFloat(couponData.minOrder || "0");
        if (subtotal < minCouponOrder) {
          throw new HttpsError(
            "failed-precondition",
            `Coupon require minimum active purchase of: ${minCouponOrder} JOD.`
          );
        }

        // Calculate absolute discount
        const type = couponData.discountType;
        const value = parseFloat(couponData.value || "0");

        if (type === "Percentage") {
          discount = subtotal * (value / 100.0);
        } else {
          discount = value;
        }

        discount = parseFloat(Math.min(discount, subtotal).toFixed(3));
        appliedCouponId = couponDoc.id;
      }

      // Final Payable total calculation
      let total = (subtotal + deliveryFee + taxes) - discount;
      if (total < 0.0) total = 0.0;
      total = parseFloat(total.toFixed(3));

      // 5. Build official, tamper-free Order document
      const randomId = db.collection("orders").doc().id;
      const stamp = Date.now();
      const orderNumber = `T-${new Date().getFullYear().toString().substring(2)}-${Math.floor(1000 + Math.random() * 9000)}`;

      const finalizedOrder = {
        id: randomId,
        orderNumber: orderNumber,
        customerUid: uid,
        customerName: customerName,
        customerPhone: customerPhone,
        items: items,
        subtotal: subtotal,
        deliveryFee: deliveryFee,
        taxes: taxes,
        discount: discount,
        total: total,
        paymentMethod: paymentMethod,
        status: "pending", // Initial state MUST enforce 'pending'
        fulfillmentType: fulfillmentType,
        address: address,
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
        isDeleted: false,
        pointsAwarded: false,
        couponCode: couponCode || null,
      };

      // Set order document
      transaction.set(db.collection("orders").doc(randomId), finalizedOrder);

      // Save coupon redemption audit details and update count in transaction
      if (appliedCouponId && couponCode) {
        transaction.update(db.collection("coupons").doc(appliedCouponId), {
          usedCount: FieldValue.increment(1),
        });

        const redemptionId = db.collection("coupon_redemptions").doc().id;
        transaction.set(db.collection("coupon_redemptions").doc(redemptionId), {
          id: redemptionId,
          customerUid: uid,
          couponCode: couponCode,
          redeemedAt: FieldValue.serverTimestamp(),
        });
      }

      // Create Order Audit Log Tracker
      const logId = db.collection("order_audit_logs").doc().id;
      transaction.set(db.collection("order_audit_logs").doc(logId), {
        id: logId,
        orderId: randomId,
        action: "ORDER_CREATED",
        details: `Calculated Total: ${total} JOD. Client pricing calculations ignored in favor of core backend rules.`,
        timestamp: FieldValue.serverTimestamp(),
      });

      return {
        orderId: randomId,
        orderNumber: orderNumber,
        total: total,
      };
    });
  } catch (error: any) {
    if (error instanceof HttpsError) {
      throw error;
    }
    throw new HttpsError("internal", error.message || "An error occurred compiling order ticket.");
  }
});

/**
 * 2. awardLoyaltyPoints (Firestore Trigger)
 *
 * Runs automatically when order status transitions to "arrived" (delivered),
 * calculating and adding currency value loyalty points atomically via backend Admin.
 */
export const awardLoyaltyPoints = onDocumentUpdated("orders/{orderId}", async (event) => {
  const snap = event.data;
  if (!snap) return;

  const orderBefore = snap.before.data();
  const orderAfter = snap.after.data();

  if (!orderAfter || !orderBefore) return;

  const orderId = event.params.orderId;
  const statusBefore = orderBefore.status;
  const statusAfter = orderAfter.status;

  // Trigger Action strictly on 'delivered' state change && check pointsAwarded to guard against double award
  if (statusAfter === "delivered" && statusBefore !== "delivered" && orderAfter.pointsAwarded !== true) {
    const total = parseFloat(orderAfter.total || "0");
    const uid = orderAfter.customerUid;

    if (!uid) return;

    // Standard Business rule conversion: 1.00 JOD spent rewards 1000 points
    const earnedPoints = Math.floor(total * 1000);

    if (earnedPoints <= 0) return;

    const userRef = db.collection("users").doc(uid);

    try {
      await db.runTransaction(async (transaction) => {
        const userDoc = await transaction.get(userRef);

        if (userDoc.exists) {
          const currentPoints = parseInt(userDoc.data()?.points || "0");
          transaction.update(userRef, {
            points: currentPoints + earnedPoints,
            updatedAt: FieldValue.serverTimestamp(),
          });

          // Write immutable loyalty transactions ledger entry
          const txId = db.collection("loyalty_transactions").doc().id;
          transaction.set(db.collection("loyalty_transactions").doc(txId), {
            id: txId,
            customerUid: uid,
            pointsChanged: earnedPoints,
            transactionType: "earn",
            description: `Earned points from Ticket #${orderAfter.orderNumber}`,
            createdAt: FieldValue.serverTimestamp(),
          });

          // Flag order as points processed
          transaction.update(db.collection("orders").doc(orderId), {
            pointsAwarded: true,
            pointsEarnedCount: earnedPoints,
            updatedAt: FieldValue.serverTimestamp(),
          });

          // Append audit log
          const auditId = db.collection("order_audit_logs").doc().id;
          transaction.set(db.collection("order_audit_logs").doc(auditId), {
            id: auditId,
            orderId: orderId,
            action: "LOYALTY_POINTS_DISPATCHED",
            details: `Successfully completed. Dispatched +${earnedPoints} points to buyer UID: ${uid}.`,
            timestamp: FieldValue.serverTimestamp(),
          });
        }
      });
    } catch (err: any) {
      console.error(`Transaction failure during loyalty assignment on ticket '${orderId}': ${err.message}`);
    }
  }
});

/**
 * 3. redeemLoyaltyReward (HTTPS Callable)
 *
 * Atomically verifies and deducts points to exchange for predefined rewards,
 * generating a discount coupon for checkout and recording immutable audits.
 */
export const redeemLoyaltyReward = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError(
      "unauthenticated",
      "Authentication is required to redeem reward loyalty options."
    );
  }

  const uid = request.auth.uid;
  const rewardId = String(request.data?.rewardId || "").trim();

  // Unified rewards structure pricing points cost (1 JOD spent awards 1000 points; 20000 points = 5.5 JOD free meal)
  const rewardsCatalog: { [key: string]: { name: string; cost: number; discountValue: number; discountType: string } } = {
    "free_meal": { name: "Free Meal Coupon (5.5 JOD Value)", cost: 20000, discountValue: 5.50, discountType: "Flat" },
    "drink_reward": { name: "Free Soft Drink Coupon", cost: 1500, discountValue: 1.50, discountType: "Flat" },
    "side_reward": { name: "Free Hummus Accent", cost: 2500, discountValue: 2.50, discountType: "Flat" },
    "cash_5": { name: "5 JOD Off Coupon", cost: 5000, discountValue: 5.00, discountType: "Flat" },
  };

  const selectedReward = rewardsCatalog[rewardId];
  if (!selectedReward) {
    throw new HttpsError(
      "invalid-argument",
      "The selected reward program code was not found inside catalogs."
    );
  }

  const userRef = db.collection("users").doc(uid);

  try {
    return await db.runTransaction(async (transaction) => {
      const userDoc = await transaction.get(userRef);

      if (!userDoc.exists) {
        throw new HttpsError("not-found", "Loyalty customer user account record was not found.");
      }

      const currentPoints = parseInt(userDoc.data()?.points || "0");
      if (currentPoints < selectedReward.cost) {
        throw new HttpsError(
          "failed-precondition",
          `Insufficient points. Required: ${selectedReward.cost}, Your balance: ${currentPoints}.`
        );
      }

      const newBalance = currentPoints - selectedReward.cost;

      // 1. Deduct points atomically
      transaction.update(userRef, {
        points: newBalance,
        updatedAt: FieldValue.serverTimestamp(),
      });

      // 2. Generate a highly unique discount coupon in our coupons database
      const randomCouponCode = `REWARD-${Math.floor(100000 + Math.random() * 900000)}`;
      const couponId = db.collection("coupons").doc().id;

      // Coupons active expiration (valid for 30 days)
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + 30);

      const couponObj = {
        id: couponId,
        code: randomCouponCode,
        discountType: selectedReward.discountType,
        value: selectedReward.discountValue,
        minOrder: 1.00, // Minimal boundary to bypass edge calculations
        expiryDate: expiryDate.toISOString(),
        usageLimit: 1, // Single redemption limit
        usedCount: 0,
        isDeleted: false,
        createdForUid: uid, // Restrict this coupon to this client only
      };

      transaction.set(db.collection("coupons").doc(couponId), couponObj);

      // 3. Write negative entry into loyalty transactions ledgers
      const txId = db.collection("loyalty_transactions").doc().id;
      transaction.set(db.collection("loyalty_transactions").doc(txId), {
        id: txId,
        customerUid: uid,
        pointsChanged: -selectedReward.cost,
        transactionType: "redeem",
        description: `Redeemed ${selectedReward.name}. Generated Coupon: ${randomCouponCode}`,
        createdAt: FieldValue.serverTimestamp(),
      });

      // 4. Create coupon redemptions history block record
      const redemptionId = db.collection("coupon_redemptions").doc().id;
      transaction.set(db.collection("coupon_redemptions").doc(redemptionId), {
        id: redemptionId,
        customerUid: uid,
        couponCode: randomCouponCode,
        redeemedAt: FieldValue.serverTimestamp(),
      });

      return {
        success: true,
        couponCode: randomCouponCode,
        pointsDeducted: selectedReward.cost,
        newPointsBalance: newBalance,
      };
    });
  } catch (error: any) {
    if (error instanceof HttpsError) {
      throw error;
    }
    throw new HttpsError("internal", error.message || "Failed to redeem loyalty points reward.");
  }
});

/**
 * 4. validateCoupon (HTTPS Callable)
 *
 * Clean internal coupon verifications, checking limits, expiration,
 * minimum order requirements, and user restrictions.
 */
export const validateCoupon = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "User must be authenticated.");
  }

  const uid = request.auth.uid;
  const couponCode = String(request.data?.couponCode || "").toUpperCase().trim();
  const subtotal = parseFloat(request.data?.subtotal || "0");

  if (!couponCode) {
    throw new HttpsError("invalid-argument", "Coupon code parameter is required.");
  }

  const couponQuery = db.collection("coupons")
    .where("code", "==", couponCode)
    .where("isDeleted", "==", false)
    .limit(1);

  const couponSnap = await couponQuery.get();

  if (couponSnap.empty) {
    throw new HttpsError("not-found", "The entered coupon code was not recognized.");
  }

  const couponDoc = couponSnap.docs[0];
  const couponData = couponDoc.data();

  // Expired Verification
  const expiry = new Date(couponData.expiryDate);
  if (expiry.getTime() < Date.now()) {
    throw new HttpsError("failed-precondition", "This discount coupon has expired.");
  }

  // Global Usage Limits Check
  const maxLimit = parseInt(couponData.usageLimit || "0");
  const currentCount = parseInt(couponData.usedCount || "0");
  if (maxLimit > 0 && currentCount >= maxLimit) {
    throw new HttpsError("failed-precondition", "This coupon has reached its maximum global usage limit.");
  }

  // Specific User Restrict Verify (E.g. generated coupon from points reward or single-use)
  if (couponData.createdForUid && couponData.createdForUid !== uid) {
    throw new HttpsError("permission-denied", "This promotional voucher is restricted to another customer account.");
  }

  // Check personal redemption history
  const usageCheck = await db.collection("coupon_redemptions")
    .where("customerUid", "==", uid)
    .where("couponCode", "==", couponCode)
    .limit(1)
    .get();

  if (!usageCheck.empty) {
    throw new HttpsError("already-exists", "This coupon has already been redeemed on your account.");
  }

  // Verify subtotal
  const minOrder = parseFloat(couponData.minOrder || "0");
  if (subtotal < minOrder) {
    throw new HttpsError(
      "failed-precondition",
      `Minimum order of ${minOrder} JOD is required for this code. Current subtotal: ${subtotal} JOD.`
    );
  }

  return {
    code: couponCode,
    discountType: couponData.discountType,
    value: parseFloat(couponData.value || "0"),
    minOrder: minOrder,
  };
});
